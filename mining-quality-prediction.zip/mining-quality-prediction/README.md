# Quality Prediction in a Mining Process — ML Soft Sensor

Code companion to the *Quality Prediction in a Mining Process* internship project
(UniConverge Technologies / upskill Campus — The IoT Academy).

Predicts **% Silica Concentrate** in iron ore froth-flotation output using
process sensor data, as an early "soft sensor" ahead of delayed lab measurements.

## Dataset

This repo does **not** include the dataset. Download it from Kaggle:

> [Quality Prediction in a Mining Process](https://www.kaggle.com/datasets/edumagalhaes/quality-prediction-in-a-mining-process)

Place the CSV as `data/raw/MiningProcess_Flotation_Plant_Database.csv`.
(~737,453 rows × 24 columns, March–September 2017.)

> **Note on numbers:** The dataset uses comma decimal separators and
> European date formats — see `src/data_preprocessing.py` for correct parsing.
> This repo provides a runnable pipeline; it does not itself claim a specific
> experimental test score, since that depends on running the full pipeline
> against the complete dataset on your machine.

## Project structure

```
mining-quality-prediction/
├── data/
│   ├── raw/              # place the downloaded CSV here (not tracked)
│   └── processed/        # cleaned / feature-engineered outputs (not tracked)
├── models/                # saved trained models (not tracked)
├── notebooks/
│   └── 01_eda.ipynb       # exploratory data analysis notebook
├── src/
│   ├── config.py          # paths, constants, column lists
│   ├── data_preprocessing.py  # load, clean, parse datetimes/numerics
│   ├── eda.py              # distribution, trend, correlation plots
│   ├── time_alignment.py   # resampling & lab-measurement alignment
│   ├── feature_engineering.py  # lag features, rolling statistics
│   ├── models.py            # baseline + regression models
│   ├── evaluate.py          # MAE/RMSE/R2, residuals, feature importance
│   └── train_pipeline.py    # end-to-end orchestration script
├── requirements.txt
└── README.md
```

## Quick start

```bash
python -m venv venv
source venv/bin/activate        # venv\Scripts\activate on Windows
pip install -r requirements.txt

# 1. Place the raw CSV in data/raw/
# 2. Run the full pipeline
python src/train_pipeline.py --horizon 1H --model xgboost
```

## Pipeline stages

1. **Data preprocessing** — datetime parsing, comma-decimal conversion, dedup, dtype validation.
2. **EDA** — distributions, correlation heatmap, time-series trend plots.
3. **Time alignment** — resample 20-second process data to match hourly lab measurements; forward-fill only *past* lab values to avoid leakage.
4. **Feature engineering** — lag features and rolling mean/std of process variables, computed only from information available before the prediction timestamp.
5. **Modelling** — mean baseline, Linear Regression, Decision Tree, Random Forest, Gradient Boosting, XGBoost.
6. **Evaluation** — MAE, RMSE, R², residual plots, feature importance, chronological (not random) train/val/test split.

## Key design principle: no data leakage

All lag/rolling features and the train/val/test split are strictly
**chronological**. Nothing computed for a given prediction timestamp uses
information that would not yet be available in a real deployment (see
`src/feature_engineering.py::build_features` and
`src/time_alignment.py::chronological_split`).

## License

MIT — feel free to reuse for coursework or further experimentation.
